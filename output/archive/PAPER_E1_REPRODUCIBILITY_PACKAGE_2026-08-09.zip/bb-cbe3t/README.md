# BB-CBE-3T: Exact True-Spike Known-Answer Controls

This project validates the unpolarized spike detector and reconstruction against exact true- and false-spike Gowdy families. It also preserves the unseen-parameter confirmation that qualified the first favorable control result.

## Result

**`CBE-3T-R1-B` — the amended analytic formulas pass, but shifted unseen end-to-end reconstruction does not.**

- Re-derived true- and false-spike formulas solve the displayed field equations to numerical precision; the literal printed alternatives fail.
- Exact-family tests show that four-function VTD data loses the spike while enriched spike parameters restore it in centered controls.
- Unseen parameter recovery succeeds, but shifted periodic-domain back-evolution fails or becomes nonfinite.
- Centered diagnostic reruns pass, localizing the remaining problem to translation and periodic-wrap handling.

## Contents

- `run_cbe3t.py` — exact-family control battery.
- `run_cbe3t_r1.py` — unseen-parameter confirmation.
- `CBE3T.json`, `CBE3T_R1.json` — machine-readable results.
- `cbe3t_log*.txt` — preserved logs.

## Reproduction

Place this repository beside `bb-cbe3`, then install Python 3, NumPy, SciPy, and SymPy:

```text
parent/
├── bb-cbe3/
└── bb-cbe3t/
```

```bash
python3 run_cbe3t.py
python3 run_cbe3t_r1.py
```

## Scope

This validates a class of exact spike controls. It does not establish that the production feature in `bb-cbe3` belongs to that family.
