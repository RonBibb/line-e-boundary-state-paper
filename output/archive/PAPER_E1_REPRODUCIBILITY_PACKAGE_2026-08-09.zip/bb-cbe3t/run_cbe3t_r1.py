"""BB-CBE-3T-R1: unseen-parameter confirmation for Line E.

Runs the frozen analytic residual check and two exact-family cases declared in
BB_CBE3T_R1_UNSEEN_PARAMETER_CONFIRMATION_SPEC_2026-08-04.md.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import sympy as sp
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import run_cbe3t as base  # noqa: E402

OUTPUT = ROOT / "CBE3T_R1.json"
CASES = (
    {"name": "U1", "w": 0.35, "q0": 0.30, "q2": 0.17, "x0": 0.40},
    {"name": "U2", "w": 0.85, "q0": 0.80, "q2": -0.11, "x0": -0.55},
)


def analytic_residuals():
    tau, x, w, q0 = sp.symbols("tau x w q0", positive=True, real=True)
    k = w * sp.exp(tau) / sp.cosh(w * tau)

    p_true = (2 * tau - sp.log(sp.cosh(w * tau))
              - sp.log(1 + k**2 * x**2) - sp.log(2 * q0))
    q_true_amended = -q0 * w * (sp.exp(-2 * tau)
                                  + 2 * (w * sp.tanh(w * tau) - 1) * x**2)
    q_true_printed = 4 * q_true_amended

    p_false_amended = (-tau + sp.log(sp.cosh(w * tau))
                       + sp.log(1 + k**2 * x**2) + sp.log(2 * q0))
    p_false_printed = (-tau + sp.log(sp.cosh(w * tau))
                       - sp.log(1 + k**2 * x**2) + sp.log(2 * q0))
    q_false = (-(1 / (2 * q0)) * w * x * sp.exp(2 * tau)
               / sp.cosh(w * tau)**2 / (1 + k**2 * x**2))

    def evaluate(p, q):
        rp = (sp.diff(p, tau, 2) - sp.exp(-2 * tau) * sp.diff(p, x, 2)
              - sp.exp(2 * p) * (sp.diff(q, tau)**2
                                  - sp.exp(-2 * tau) * sp.diff(q, x)**2))
        rq = (sp.diff(q, tau, 2) - sp.exp(-2 * tau) * sp.diff(q, x, 2)
              + 2 * (sp.diff(p, tau) * sp.diff(q, tau)
                     - sp.exp(-2 * tau) * sp.diff(p, x) * sp.diff(q, x)))
        fp = sp.lambdify((tau, x, w, q0), rp, "numpy")
        fq = sp.lambdify((tau, x, w, q0), rq, "numpy")
        xs = np.linspace(-1.5, 1.5, 101)
        return {"P": float(np.max(np.abs(fp(3.0, xs, 0.55, 0.5)))),
                "Q": float(np.max(np.abs(fq(3.0, xs, 0.55, 0.5))))}

    rows = {
        "true_amended": evaluate(p_true, q_true_amended),
        "true_printed": evaluate(p_true, q_true_printed),
        "false_amended": evaluate(p_false_amended, q_false),
        "false_printed": evaluate(p_false_printed, q_false),
    }
    amended = max(list(rows["true_amended"].values())
                  + list(rows["false_amended"].values()))
    printed = max(list(rows["true_printed"].values())
                  + list(rows["false_printed"].values()))
    return {"rows": rows,
            "amended_max": amended,
            "printed_max": printed,
            "passes": bool(amended <= 1.0e-12 and printed > 1.0e-4)}


def exact_family(case):
    def family(x, tau):
        p, q, lam = base.true_spike(x - case["x0"], tau,
                                     w=case["w"], q0=case["q0"])
        return p, q + case["q2"], lam
    return family


def run_case(case):
    n = 4096
    x, dx = base.grid(n)
    family = exact_family(case)
    p_f, q_f, _ = family(x, base.TAU_F)
    p_w, _, _ = family(x, base.TAU_F - 2.0)
    velocity = (p_f - p_w) / 2.0
    components = [c for c in base.spike_components(velocity, q_f, dx)
                  if abs(x[c["center"]]) <= base.SCORE_HALF_WIDTH
                  and c["kind"] == "TRUE"]

    if len(components) != 2:
        return {"case": case, "true_component_count": len(components),
                "passes": False, "failure": "not exactly two TRUE components"}

    x0_hat = float(np.mean([x[c["center"]] for c in components]))
    center = int(np.argmin(np.abs(x - x0_hat)))
    v_center = float(velocity[center])

    def window_mismatch(w):
        return (2.0 - (np.log(np.cosh(w * base.TAU_F))
                       - np.log(np.cosh(w * (base.TAU_F - 2.0)))) / 2.0
                - v_center)

    w_hat = float(brentq(window_mismatch, 1.0e-3, 0.999))
    q0_hat = float(0.5 * np.exp(
        2.0 * base.TAU_F - np.log(np.cosh(w_hat * base.TAU_F))
        - p_f[center]))
    q2_hat = float(q_f[center]
                   + q0_hat * w_hat * np.exp(-2.0 * base.TAU_F))

    fitted = {"w": w_hat, "q0": q0_hat, "q2": q2_hat,
              "x0": x0_hat}

    def reconstructed(xa, tau):
        p, q, lam = base.true_spike(xa - x0_hat, tau,
                                     w=w_hat, q0=q0_hat)
        return p, q + q2_hat, lam

    y_f = base.exact_state(reconstructed, x, base.TAU_F)
    _, _, stored = base.evolve(y_f, base.TAU_F, 0.0, n,
                               store_taus=base.T4_TAUS)
    errors = {}
    for tc in base.T4_TAUS:
        p_exact, q_exact, _ = family(x, tc)
        distance = base.hyperbolic_distance(
            stored[tc][0], stored[tc][2], p_exact, q_exact)
        value = float(np.max(distance[base.scored_mask(x)]))
        errors[str(tc)] = value if np.isfinite(value) else None

    recovery = {
        "x0_abs": abs(x0_hat - case["x0"]),
        "w_abs": abs(w_hat - case["w"]),
        "q0_relative": abs(q0_hat - case["q0"]) / case["q0"],
        "q2_abs": abs(q2_hat - case["q2"]),
    }
    passes = (recovery["x0_abs"] <= 2.0 * dx
              and recovery["w_abs"] <= 5.0e-4
              and recovery["q0_relative"] <= 1.0e-3
              and recovery["q2_abs"] <= 1.0e-4
              and all(v is not None and v <= 1.0e-2
                      for v in errors.values()))
    return {"case": case, "true_component_count": len(components),
            "component_x": [float(x[c["center"]]) for c in components],
            "dx": float(dx), "fitted": fitted, "recovery_errors": recovery,
            "backward_sup_D": errors, "passes": bool(passes)}


def main():
    analytic = analytic_residuals()
    cases = [run_case(case) for case in CASES]
    if not analytic["passes"]:
        outcome = "CBE-3T-R1-C"
    elif all(case["passes"] for case in cases):
        outcome = "CBE-3T-R1-A"
    else:
        outcome = "CBE-3T-R1-B"
    result = {"program": "BB-CBE-3T-R1", "line": "E",
              "analytic": analytic, "unseen_cases": cases,
              "outcome": outcome}
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True,
                                 allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
